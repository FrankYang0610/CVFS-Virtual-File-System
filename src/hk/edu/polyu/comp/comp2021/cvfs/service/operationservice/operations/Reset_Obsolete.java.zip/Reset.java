package hk.edu.polyu.comp.comp2021.cvfs.service.operationservice.operations;

import hk.edu.polyu.comp.comp2021.cvfs.service.operationservice.InvalidCommandException;
import hk.edu.polyu.comp.comp2021.cvfs.model.filesystem.FileSystem;
import hk.edu.polyu.comp.comp2021.cvfs.service.operationservice.OperationRecord;

/**
 * <h3>The {@code Reset} Operation Class</h3>
 * This class encapsulates the operation of the {@code reset} command, which is used to reset the application in the when a fatal error occurs, such as an external injection deleting the working directory. The instruction document does not require to include this operation, we use it ourselves to enhance the system stability.
 */
public final class Reset implements Operation {
    FileSystem fs;

    OperationRecord operationRecord;

    public Reset(FileSystem fs, OperationRecord operationRecord, String[] command) throws InvalidCommandException {
        commandValidityCheck(command);
        this.fs = fs;
        this.operationRecord = operationRecord;
    }

    @Override
    public String exec() {
        fs.releaseResource();
        operationRecord.clearAll();
        return "The application is reset successfully, and all resources are released.";
    }

    @Override
    public void commandValidityCheck(String[] command) throws InvalidCommandException {
        if (command.length != 1) {
            throw new InvalidCommandException("Wrong number of parameters: " + (command.length - 1) + ".");
        }
    }
}

